# screens/tripulation_screen.rpy
# Screen for selecting which crew member's area to visit.

screen tripulation_screen():

    # Header box
    frame:
        xalign 0.5
        yalign 0.08
        xsize 1000
        background Solid("#1e293bee")
        padding (30, 15)
        text "¿A qué área del asentamiento deseas dirigirte?" size 28 color "#38bdf8" xalign 0.5

    # Character selection row - three columns evenly distributed
    hbox:
        xalign 0.5
        yalign 0.55
        spacing 100

        # --- Miquel ---
        vbox:
            xalign 0.5
            spacing 10

            text "Miquel" size 30 bold True color "#7ed957" xalign 0.5
            text "Taller de Mantenimiento" size 22 color "#94a3b8" xalign 0.5

            fixed:
                xsize 220
                ysize 380
                add "images/characters/miquel_cuerpoentero.png" zoom 0.32 xalign 0.5 yalign 0.0
                button:
                    xpos 0
                    ypos 0
                    xsize 220
                    ysize 380
                    background None
                    hover_background None
                    action Jump("informe_miquel_dialogo")

        # --- Hanna ---
        vbox:
            xalign 0.5
            spacing 10

            text "Hanna" size 30 bold True color "#ff751f" xalign 0.5
            text "Puesto de Bio-Robótica" size 22 color "#94a3b8" xalign 0.5

            fixed:
                xsize 220
                ysize 380
                add "images/characters/hanna_cuerpoentero.png" zoom 0.38 xalign 0.5 yalign 0.0
                button:
                    xpos 0
                    ypos 0
                    xsize 220
                    ysize 380
                    background None
                    hover_background None
                    action Jump("informe_hanna_dialogo")

        # --- Nelson ---
        vbox:
            xalign 0.5
            spacing 10

            text "Nelson" size 30 bold True color "#f423a3" xalign 0.5
            text "Laboratorio de Geología" size 22 color "#94a3b8" xalign 0.5

            fixed:
                xsize 220
                ysize 380
                add "images/characters/nelson_cuerpoentero.png" zoom 0.22 xalign 0.5 yalign 0.0
                button:
                    xpos 0
                    ypos 0
                    xsize 220
                    ysize 380
                    background None
                    hover_background None
                    action Jump("informe_nelson_dialogo")

    # Reunion button (only when all reports are done)
    if informe_nelson and informe_hanna and informe_miquel:
        frame:
            xalign 0.5
            yalign 0.18
            background Solid("#1e293bee")
            padding (30, 12)
            button:
                background None
                hover_background None
                action Jump("fin_reunion_asentamiento")
                text "Reunir al equipo y planificar el Día 2" size 22 color "#38bdf8"
